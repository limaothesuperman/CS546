//You will code the route in this file
//Lecture Code Refernece -> https://github.com/stevens-cs546-cs554/CS-546/tree/master/lecture_05/code/routes

const router = express.Router();

router
  .route('/pokemon')
//Request Method

router
  .route('/pokemon/:id')
//Request Method

module.exports = router;