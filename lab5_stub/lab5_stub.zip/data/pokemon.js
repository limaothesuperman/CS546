//Your data modules to make the Axios calls and get the data

const pokemon = async () => { };

const pokemonById = async (id) => { };

module.exports = {};