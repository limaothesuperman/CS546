//Axios call to get all data
const getAllPeople = async () => {};

//Function to list of up to 20 people matching the searchPersonName (sorted by id)
const searchPeopleByName = async (searchPersonName) => {};

//Function to list person matching the id
const searchPeopleByID = async (id) => {};

module.exports = { searchPeopleByName, searchPeopleByID };
