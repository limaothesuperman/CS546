const createMovie = async (
  title,
  plot,
  genres,
  rating,
  studio,
  director,
  castMembers,
  dateReleased,
  runtime
) => {};

const getAllMovies = async () => {};

const getMovieById = async (id) => {};

const removeMovie = async (id) => {};

const renameMovie = async (id, newName) => {};

module.exports = {};
