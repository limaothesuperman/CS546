const createMovie = async (
  title,
  plot,
  genres,
  rating,
  studio,
  director,
  castMembers,
  dateReleased,
  runtime
) => {};

const getAllMovies = async () => {};

const getMovieById = async (movieId) => {};

const removeMovie = async (movieId) => {};

const updateMovie = async (
  movieId,
  title,
  plot,
  genres,
  rating,
  studio,
  castMembers,
  dateReleased,
  runtime
) => {};

const renameMovie = async (id, newName) => {
  //Not used for this lab
};

module.exports = {};
