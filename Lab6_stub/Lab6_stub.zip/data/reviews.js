const createReview = async (
  movieId,
  reviewTitle,
  reviewerName,
  review,
  rating
) => {};

const getAllReviews = async (movieId) => {};

const getReview = async (reviewId) => {};

const removeReview = async (reviewId) => {};

module.exports = {};
