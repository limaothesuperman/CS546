const lab1 = require('./lab1');

//TODO: Write and call each function in lab1.js 5 times each, passing in different input
