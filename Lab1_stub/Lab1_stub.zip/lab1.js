function questionOne(arr) {
  // TODO: Implement question 1 here
}

function questionTwo(startingNumber, commonRatio, numberOfTerms) {
  // TODO: Implement question 2 here
}

function questionThree(str) {
  // TODO: Implement question 3 here
}

function questionFour(fullString, substring) {
  // TODO: Implement question 4 here
}

//TODO:  Change the values for firstName, lastName and studentId
module.exports = {
  firstName: 'TODO: REPLACE WITH YOUR FIRST NAME',
  lastName: 'TODO: REPLACE WITH YOUR LAST NAME',
  studentId: 'TODO: REPLACE WITH YOUR STUDENT ID',
  questionOne,
  questionTwo,
  questionThree,
  questionFour,
};
