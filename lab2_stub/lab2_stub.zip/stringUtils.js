/* Todo: Implment the functions below and then export them
      using the module.exports syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let palindromes = (string) => {};

let replaceChar = (string) => {};

let charSwap = (string1, string2) => {};
