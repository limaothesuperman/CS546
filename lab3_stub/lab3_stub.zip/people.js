const getPersonById = async (id) => {};

const sameJobTitle = async (jobTitle) => {};

const getPostalCodes = async (city, state) => {};

const sameCityAndState = async (city, state) => {};

module.exports = {};
