const listEmployees = async (companyName) => {};

const sameIndustry = async (industry) => {};

const getCompanyById = async (id) => {};

module.exports = {};
